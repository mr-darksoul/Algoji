package com.example.algoji;

public enum ImagePickerEnum {

    FROM_GALLERY,
    FROM_CAMERA
}
